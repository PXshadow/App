package org.haxe.extension.nativetext;


public enum NativeTextFieldReturnKeyType
{
    Default,
    Go,
    Next,
    Search,
    Send,
    Done,
}
