package org.haxe.extension.nativetext;


public enum NativeTextFieldKeyboardType
{
    Default,
    Password,
    Decimal,
    Name,
    Email,
    Phone,
    URL,
}
