package org.haxe.extension.nativetext;


public class NativeTextFieldConfigCommand
{
    public int eventId;
    public NativeTextFieldConfig config;

}
