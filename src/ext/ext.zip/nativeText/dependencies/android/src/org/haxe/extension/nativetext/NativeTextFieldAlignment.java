package org.haxe.extension.nativetext;


public enum NativeTextFieldAlignment
{
    Natural,
    Left,
    Center,
    Right,
}
